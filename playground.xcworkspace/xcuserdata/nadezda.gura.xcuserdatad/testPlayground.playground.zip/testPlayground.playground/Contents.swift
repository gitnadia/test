import UIKit

var greeting = "Hello, playground"
print ("var greeting")


let a = "Test session"
print(a)

